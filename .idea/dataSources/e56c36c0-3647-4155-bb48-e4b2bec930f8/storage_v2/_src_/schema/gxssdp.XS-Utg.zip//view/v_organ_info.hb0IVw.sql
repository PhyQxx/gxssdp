create definer = root@localhost view v_organ_info as
select `sof`.`OFFICE_ID`      AS `OFFICE_ID`,
       `sof`.`STRU_ID`        AS `STRU_ID`,
       `sof`.`OFFICE_ALIAS`   AS `OFFICE_ALIAS`,
       `sof`.`OFFICE_ADDRESS` AS `OFFICE_ADDRESS`,
       `st`.`ORGAN_ID`        AS `ORGAN_ID`,
       `so`.`ORGAN_NAME`      AS `ORGAN_NAME`,
       `so`.`SHORT_NAME`      AS `SHORT_NAME`,
       `st`.`ORGAN_ALIAS`     AS `ORGAN_ALIAS`,
       `st`.`STRU_TYPE`       AS `STRU_TYPE`,
       `sot`.`TYPE_NAME`      AS `TYPE_NAME`,
       `st`.`PARENT_ID`       AS `PARENT_ID`,
       `st`.`PRINCIPAL_ID`    AS `PRINCIPAL_ID`,
       `st`.`IN_USE`          AS `IN_USE`
from (((`gxssdp`.`sys_stru` `st` left join `gxssdp`.`sys_organ` `so` on ((`st`.`ORGAN_ID` = `so`.`ORGAN_ID`))) left join `gxssdp`.`sys_organ_type` `sot` on ((`st`.`STRU_TYPE` = `sot`.`ORGAN_TYPE`)))
         left join `gxssdp`.`sys_office` `sof` on ((`st`.`STRU_ID` = `sof`.`STRU_ID`)))
where (`st`.`STRU_TYPE` <> '9')
order by `st`.`STRU_LEVEL`, `st`.`STRU_ORDER`, `st`.`GLOBAL_ORDER`;

-- comment on column v_organ_info.OFFICE_ID not supported: 组织机构id

-- comment on column v_organ_info.STRU_ID not supported: 对应的组织结构id（注：不是所属）

-- comment on column v_organ_info.OFFICE_ALIAS not supported: 组织机构描述

-- comment on column v_organ_info.OFFICE_ADDRESS not supported: 联系地址

-- comment on column v_organ_info.ORGAN_ID not supported: 组织编码

-- comment on column v_organ_info.ORGAN_NAME not supported: 组织名称

-- comment on column v_organ_info.SHORT_NAME not supported: 组织简称

-- comment on column v_organ_info.ORGAN_ALIAS not supported: 组织别名

-- comment on column v_organ_info.TYPE_NAME not supported: 组织类型名称

-- comment on column v_organ_info.PARENT_ID not supported: 上级结构编码

-- comment on column v_organ_info.PRINCIPAL_ID not supported: 负责人组织编码

-- comment on column v_organ_info.IN_USE not supported: 使用标识

