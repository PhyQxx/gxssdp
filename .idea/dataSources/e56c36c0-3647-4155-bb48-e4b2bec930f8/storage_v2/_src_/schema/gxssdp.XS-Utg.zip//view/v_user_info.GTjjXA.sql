create definer = root@localhost view v_user_info as
select `su`.`USER_ID`        AS `USER_ID`,
       `su`.`USER_NAME`      AS `USER_NAME`,
       `su`.`EMPLOYEE_ID`    AS `EMPLOYEE_ID`,
       `su`.`DEPARTMENT_ID`  AS `DEPARTMENT_ID`,
       `emp`.`ORGAN_ALIAS`   AS `EMP_NAME`,
       `su`.`USER_ACCOUNT`   AS `USER_ACCOUNT`,
       `st`.`IN_USE`         AS `IN_USE`,
       `su`.`ACCOUNT_STATUS` AS `ACCOUNT_STATUS`,
       `su`.`IS_SYS`         AS `IS_SYS`
from ((`gxssdp`.`sys_users` `su` left join `gxssdp`.`sys_stru` `st` on ((`su`.`DEPARTMENT_ID` = `st`.`STRU_ID`)))
         left join `gxssdp`.`sys_stru` `emp` on ((`su`.`EMPLOYEE_ID` = `emp`.`STRU_ID`)));

-- comment on column v_user_info.USER_ID not supported: 用户编码

-- comment on column v_user_info.USER_NAME not supported: 用户名称

-- comment on column v_user_info.EMPLOYEE_ID not supported: 员工结构编码

-- comment on column v_user_info.DEPARTMENT_ID not supported: 部门结构编码

-- comment on column v_user_info.EMP_NAME not supported: 组织别名

-- comment on column v_user_info.USER_ACCOUNT not supported: 用户登录账号

-- comment on column v_user_info.IN_USE not supported: 使用标识

-- comment on column v_user_info.ACCOUNT_STATUS not supported: 状态(0:锁定;1:开放;2删除)

-- comment on column v_user_info.IS_SYS not supported: 是否系统管理员

