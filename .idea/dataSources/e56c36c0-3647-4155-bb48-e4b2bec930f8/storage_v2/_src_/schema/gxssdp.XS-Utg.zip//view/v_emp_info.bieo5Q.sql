create definer = root@localhost view v_emp_info as
select `st`.`STRU_ID`         AS `EMPLOYEE_ID`,
       `so`.`ORGAN_NAME`      AS `EMPLOYEE_NAME`,
       `st`.`STAFF_POSITION`  AS `STAFF_POSITION`,
       `st`.`IN_USE`          AS `IN_USE`,
       `ss`.`staff_id`        AS `staff_id`,
       `ss`.`stru_id`         AS `stru_id`,
       `ss`.`name`            AS `name`,
       `ss`.`birthday`        AS `birthday`,
       `ss`.`sex`             AS `sex`,
       `ss`.`idcard`          AS `idcard`,
       `ss`.`address`         AS `address`,
       `ss`.`work_id`         AS `work_id`,
       `ss`.`work_date`       AS `work_date`,
       `ss`.`graduate_school` AS `graduate_school`,
       `ss`.`graduate_date`   AS `graduate_date`
from ((`gxssdp`.`sys_stru` `st` left join `gxssdp`.`sys_organ` `so` on ((`st`.`ORGAN_ID` = `so`.`ORGAN_ID`)))
         left join `gxssdp`.`sys_staff` `ss` on ((`st`.`STRU_ID` = `ss`.`stru_id`)))
where (`st`.`STRU_TYPE` = '9')
order by `st`.`STRU_LEVEL`, `st`.`STRU_ORDER`, `st`.`GLOBAL_ORDER`;

-- comment on column v_emp_info.EMPLOYEE_ID not supported: 结构编码

-- comment on column v_emp_info.EMPLOYEE_NAME not supported: 组织名称

-- comment on column v_emp_info.STAFF_POSITION not supported: 职务编码

-- comment on column v_emp_info.IN_USE not supported: 使用标识

-- comment on column v_emp_info.staff_id not supported: 主键

-- comment on column v_emp_info.stru_id not supported: 人员id

-- comment on column v_emp_info.name not supported: 姓名

-- comment on column v_emp_info.birthday not supported: 生日

-- comment on column v_emp_info.sex not supported: 性别

-- comment on column v_emp_info.idcard not supported: 身份证

-- comment on column v_emp_info.address not supported: 住址

-- comment on column v_emp_info.work_date not supported: 工作时间

-- comment on column v_emp_info.graduate_school not supported: 毕业学校

-- comment on column v_emp_info.graduate_date not supported: 毕业时间

